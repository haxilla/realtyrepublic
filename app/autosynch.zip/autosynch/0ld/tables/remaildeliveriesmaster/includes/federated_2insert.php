<?php

Use App\models\synch\synchLog;

//alert if no propdelivs table
if(!Schema::hasTable('propdelivs')){
    dd('no propdelivs table!');
};

//drop
Schema::connection('remarchives')
->dropIfExists('remaildeliveriesmaster');

//notify synch of tableDrop
synchLog::where('synchID','=',$synchID)
->update([
  'tableDrop'=>1
  'progressMessage'=>'Working on inserts into remdeliveriesmaster'
]);

//re-create
$results=DB::select( DB::raw("
  create table remarchives.remaildeliveriesmaster
  like propdelivs
"));

// Insert
DB::select( DB::raw("
  INSERT INTO remarchives.remaildeliveriesmaster
    (
    propflyer_id,
    emSubject,
    emArea,
    emStart,
    emComplete,
    emRequest,
    cid,
    propagent_id,
    emArea_display,
    campLabel,
    totalEmails,
    lastEI,
    startRow,
    campCreated,
    template,
    priority,
    rush,
    rushDate,
    amtEmails,
    delay,
    resumeURL,
    emailsLeft,
    closingLine,
    removeLink,
    warp15,
    warp6,
    emAlt,
    suspend,
    authorized,
    camp_order,
    gmail_done,
    cox_done,
    msn_done,
    yahoo_done,
    aol_done,
    misc_done,
    emalt_msn,
    emalt_yahoo,
    emalt_cox,
    emalt_aol,
    admin_add,
    authNum,
    remCreds,
    server,
    free
    )
  SELECT
    ufid,
    emailSubject,
    emailarea,
    emailstarted,
    emailfinished,
    emailrequested,
    campaignid,
    umid,
    emailarea_display,
    camplabel,
    totalemails,
    lastei,
    sentsofar,
    campcreated,
    template,
    priority,
    rush,
    rushdate,
    amtemails,
    delay,
    resumeurl,
    emailsleft,
    closingline,
    removelink,
    warp15,
    warp6,
    emAlt,
    suspend,
    authorized,
    camp_order,
    gmail_done,
    cox_done,
    msn_done,
    yahoo_done,
    aol_done,
    misc_done,
    emalt_msn,
    emalt_yahoo,
    emalt_cox,
    emalt_aol,
    admin_add,
    authNum,
    remcreds,
    server,
    free
  FROM  remailsynch.remaildeliveriesmaster_federated
"));

//notify synch of tableDrop
synchLog::where('synchID','=',$synchID)
->update([
  'tableDrop'=>0,
  'progressMessage'=>null,
]);
