<?php

//get model
use App\autosynch\models\propphoto\propphotos;
use App\autosynch\models\propphoto\propphotoOld;
use App\autosynch\models\propphoto\propphotoCurArc;
use App\autosynch\models\propphoto\propphotoOldArc;

//if tall resize to 300height otherwise 300wide
if($orient=='tall'){
   $resize_h='600';
   $targetWidth=$resize_h*$ratio;
   $resize_w=round($targetWidth);
   $filePrefix='h600';
   //echo "<BR>ORIENT: $orient - H: $newHeight X W: $targetWidth<BR>";
}else{
   $resize_w='1000';
   $targetHeight=$resize_w/$ratio;
   $resize_h=round($targetHeight);
   $filePrefix='w1000';}
   //echo "<BR>ORIENT: $orient - W: $newWidth X H: $targetHeight<BR>";

if(!$the->photoName){
   dd('error-line23-autosynch/resize/functions/resize1000w600h');}

//set variables for photo resizing
$photoPath     = "hqphotos/$zipDir/$mlsDir/$the->photoName";
$file          = $photoPath;
$resizedName   = "$filePrefix-$the->photoName";
$resizedLoc    = "hqphotos/$zipDir/$mlsDir/$resizedName";

//call the function (when passing path to pic)
smart_resize_image($file ,null, $resize_w, $resize_h, false, $resizedLoc, false, false, 90 );

//re-assign the name and resized values
$newFileName=$resizedName;
$newFileSize=filesize($resizedLoc);
$resized=1000;

if(file_exists($resizedLoc)){
   $localFound=1;
}else{
   dd('error-line44-autosynch/functions/resize1000w600h');}

//add dimension values of original - gets width/height
list($width, $height) = getimagesize($resizedLoc);

//get new dimensions & add values
$ratio=$width/$height;
$ratio=round($ratio,4);

//update original resized
propphotos::where('photoID','=',"$the->photoID")
->update([
   'resized'     => 1,
   'existCheck'  => \Carbon\Carbon::now(),
   'localFound'  => $localFound,
]);

$matchLocname     = array('locname' =>$newFileName);
$matchPhotoname   = array('photoName' =>$newFileName);
//propphotos contains merged archives
//insert resized record into database
propphotos::updateOrCreate($matchPhotoname,[
   'resized'      => $resized,
   'resize_w'     => $resize_w,
   'resize_h'     => $resize_h,
   'width'        => $width,
   'height'       => $height,
   'ratio'        => $ratio,
   'photoName'    => $newFileName,
   'newFileSize'  => $newFileSize,
   'oldFileName'  => $the->photoName,
   'oldFileSize'  => $the->oldFileSize,
   'orient'       => $orient,
   'propflyer_id' => $the->propflyer_id,
   'propagent_id' => $the->propagent_id,
   'ord'          => $the->ord,
   'def'          => $the->def,
   'existCheck'   => \Carbon\Carbon::now(),
   'localFound'   => $localFound
]);

//remote
//remote originalFile
$remoteOriginal=propphotoOld::select('photoID')
->where('locname','=',"$the->photoName")
->first();
//remote newFile
$remoteResize=propphotoOld::select('photoID')
->where('locname','=',"$newFileName")
->first();

// if original photo is found in remailphotos
// add resize to remailphotos
if($remoteOriginal && !$remoteResize){

   //update original remailphotos
   propphotoOld::where('locname','=',"$the->photoName")
   ->update([
      'resized'      => 1,
      'ratio'        => $ratio,
      'exist_check'  => \Carbon\Carbon::now(),
   ]);

   //maker resize record on remailphotos
   propphotoOld::updateOrCreate($matchLocname,[
      'ufid'         => $the->propflyer_id,
      'umid'         => $the->propagent_id,
      'origname'     => $the->photoName,
      'locname'      => $newFileName,
      'filesize'     => $newFileSize,
      'ord'          => $the->ord,
      'def'          => $the->def,
      'width'        => $width,
      'height'       => $height,
      'orient'       => $orient,
      'resized'      => $resized,
      'ratio'        => $ratio,
      'exist_check'  => \Carbon\Carbon::now(),
   ]);
}

//****************//
// Check Archive  //
//****************//
$localArchive=propphotoCurArc::select('photoID')
->where('locname','=',"$the->photoName")
->first();
//if original is found in archive
//add the resize so re-added on new synch
if($localArchive){

   //update remote archive
   propphotoOldArc::where('locname','=',"$the->photoName")
   ->update([
      'resized'      => 1,
      'localFound'   => 1,
      'exist_check'  => \Carbon\Carbon::now(),
   ]);

   //update local archive
   propphotoCurArc::where('locname','=',"$the->photoName")
   ->update([
      'resized'      => 1,
      'localFound'   => 1,
      'exist_check'  => \Carbon\Carbon::now(),
   ]);

   //make archive
   $addLocalArchive=propphotoCurArc::updateOrCreate($matchLocname,[
      'ufid'         => $the->propflyer_id,
      'umid'         => $the->propagent_id,
      'origname'     => $the->photoName,
      'locname'      => $newFileName,
      'filesize'     => $newFileSize,
      'ord'          => $the->ord,
      'def'          => $the->def,
      'width'        => $width,
      'height'       => $height,
      'orient'       => $orient,
      'resized'      => $resized,
      'ratio'        => $ratio,
      'exist_check'  => \Carbon\Carbon::now(),
      'localFound'   => $localFound
   ]);

   //use same ID to match
   $newPhotoID=$addLocalArchive['photoID'];

   //make archive
   $addRemoteArchive=propphotoOldArc::updateOrCreate($matchLocname,[
      'photoID'      => $newPhotoID,
      'ufid'         => $the->propflyer_id,
      'umid'         => $the->propagent_id,
      'origname'     => $the->photoName,
      'locname'      => $newFileName,
      'filesize'     => $newFileSize,
      'ord'          => $the->ord,
      'def'          => $the->def,
      'width'        => $width,
      'height'       => $height,
      'orient'       => $orient,
      'resized'      => $resized,
      'ratio'        => $ratio,
      'exist_check'  => \Carbon\Carbon::now(),
      'localFound'   => $localFound
   ]);

}


